import requests
import os
import allure
from dotenv import load_dotenv
from typing import Dict, Any

load_dotenv()

class TandoorAPIClient:
    """Клиент для взаимодействия с API сервиса Tandoor"""

    def __init__(self, BASE_URL=None, token=None):
        """Инициализация API клиента"""

        # Загружаем данные из .env, если они не переданы явно
        self.BASE_URL = BASE_URL or os.getenv("BASE_URL", "https://app.tandoor.dev") # Базовый URL API, берется из .env
        self.token = token or os.getenv("TANDOOR_TOKEN") # Токен авторизации, берется из .env

        # Заголовки авторизации для всех запросов
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        self.session = requests.Session() # Сессия для эффективного использования соединений
        self.session.headers.update(self.headers)

    """Базовые методы"""

    def _make_request(self, method, endpoint, **kwargs):
        """Базовый метод для выполнения всех API запросов"""
        url = f"{self.BASE_URL}/api/{endpoint}"

        try:
            # Выполняет запрос
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status() #Выбрасывает исключение при HTTP ошибке

            # Для DELETE запросов не парсит JSON, просто возвращаем True
            if method == 'DELETE':
                return True  # Успешное удаление

            # Для GET/POST/PUT запросов возвращаем JSON
            return response.json()

        except requests.exceptions.HTTPError as e:
            # Обрабатывает HTTP ошибок (404, 401, 500 и т.д.)
            print(f"HTTP Error {e.response.status_code}: {e}")
            if e.response is not None:
                print(f"📄 Тело ошибки: {e.response.text}")
            return None if method != 'DELETE' else False

        except Exception as e:
            # Обрабатывает прочие ошибки
            print(f"Ошибка: {e}")
            return None if method != 'DELETE' else False

    """Системные методы"""

    @allure.step("Получить информацию об API")
    def get_api_info(self):
        """Получает информацию об API."""
        try:
            response = self.session.get(f"{self.BASE_URL}/api/")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"error": str(e)}

    """Методы для работы с рецептами"""

    @allure.step("Получить список рецептов")
    def get_recipes (self, params=None):
        """Получает список всех рецептов"""
        return self._make_request("GET", "recipe/", params=params)

    @allure.step("Получить по IP рецепт: {recipe_id}")
    def get_recipe_by_id(self, recipe_id: int) -> Dict[str, Any]:
        """Получает рецепт по ID"""
        return self._make_request('GET', f'recipe/{recipe_id}/')

    @allure.step("Создать рецепт с данными")
    def create_recipe(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Создает новый рецепт с данными"""
        return self._make_request('POST', 'recipe/', json=data)

    @allure.step("Удалить по IP рецепт: {recipe_id}")
    def delete_recipe(self, recipe_id):
        """Удаляет рецепт по ID"""
        url = f"{self.BASE_URL}/api/recipe/{recipe_id}/"

        # Получает CSRF токен из cookies, если есть
        csrf_token = self.session.cookies.get('csrftoken', '')

        # Копирует существующие заголовки
        headers = self.headers.copy() if hasattr(self, 'headers') else {}

        # Добавляет специфичные заголовки
        headers.update({
            "X-Requested-With": "XMLHttpRequest",
            "Referer": self.BASE_URL,
        })

        # Добавляет CSRF токен, если он есть
        if csrf_token:
            headers["X-CSRFToken"] = csrf_token

        return self.session.delete(url, headers=headers)

    @allure.step("Импортировать рецепт из источников по URL")
    def import_recipe_from_source(self, url: str) -> Dict[str, Any]:
        """
        Импортирует рецепт из внешнего источника без сохранения
        Args:
            url: URL рецепта для импорта

        Returns:
            Dict с распарсенными данными рецепта
        """
        data = {"url": url}
        print(f"📤 Импортируем рецепт из источника: {url}")

        response = self._make_request("POST", "recipe-from-source/", json=data)

        if response:
            if response.get('error'):
                print(f"❌ Ошибка импорта: {response.get('msg', 'Unknown error')}")
            else:
                recipe_data = response.get('recipe', {})
                print(f"✅ Рецепт распарсен: {recipe_data.get('name', 'Unknown')}")
                if response.get('recipe_id'):
                    print(f"📌 ID рецепта в системе: {response.get('recipe_id')}")

        return response

    """Методы для работы с планами питания"""

    @allure.step("Создать план питания")
    def create_meal_plan(self, data):
        """Создает план питания"""
        return self._make_request("POST", "meal-plan/", json=data)

    @allure.step("Получить по ID план питания: {meal_plan_by_ID}")
    def get_meal_plan_by_ID(self, meal_plan_by_ID):
        """Получает план питания по ID"""
        return self._make_request("GET", f'meal-plan/{meal_plan_by_ID}/')

    @allure.step("Получить список всех планов питания")
    def get_meal_plan_list(self) -> Dict[str, Any]:
        """Получает список всех планов питания"""
        return self._make_request("GET","meal-plan/")

    @allure.step("Удалить по ID план питания: {meal_plan_by_ID}")
    def delete_meal_plan(self, meal_plan_by_ID):
        """Удаляет план питания по ID"""
        return self._make_request("DELETE", f"meal-plan/{meal_plan_by_ID}/")

    """Методы для работы со списком покупок"""

    @allure.step("Добавить вручную в список покупок продукты: {shopping_list_data}")
    def create_shopping_list(self, shopping_list_data):
        """Добавляет продукты в список покупок вручную (не по рецепту)"""
        return self._make_request("POST", "shopping-list-entry/", json=shopping_list_data)

    @allure.step("Получить список покупок продуктов добавленных вручную: {shopping_list_by_ID}")
    def get_shopping_list(self, shopping_list_by_ID):
        """Получает список покупок, добавленных вручную (не по рецепту)"""
        return self._make_request("GET", f"shopping-list-entry/{shopping_list_by_ID}/")

    @allure.step("Удалить список покупок продуктов добавленных вручную: {shopping_list_by_ID}")
    def delete_shopping_list(self, shopping_list_by_ID):
        """Удаляет список покупок, добавленных вручную (не по рецепту)"""
        return self._make_request("DELETE", f"shopping-list-entry/{shopping_list_by_ID}/")

    @allure.step("Добавить по рецепту в список покупок продукты: {shopping_list_data_for_recipe}")
    def create_shopping_list_on_recipe(self, shopping_list_data_for_recipe):
        """Добавляет продукты в список покупок по рецепту"""
        return self._make_request('POST', 'shopping-list-recipe/', json=shopping_list_data_for_recipe)

    @allure.step("Получить список покупок продуктов добавленных по рецепту: {shopping_list_by_recipe}")
    def get_shopping_list_on_recipe(self, shopping_list_by_recipe):
        """Получает список покупок, добавленных по рецепту"""
        return self._make_request('GET', f'shopping-list-recipe/{shopping_list_by_recipe}')

    @allure.step("Удалить список покупок продуктов добавленных по рецепту: {shopping_list_by_recipe}")
    def delete_shopping_list_on_recipe(self, shopping_list_by_recipe):
        """Удаляет список покупок, добавленных по рецепту"""
        return self._make_request('DELETE', f'shopping-list-recipe/{shopping_list_by_recipe}/')

    """Методы для работы со с типами питания"""

    @allure.step("Создать тип питания")
    def create_meal_type(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Создает тип питания (Завтрак, Обед, Ужин)"""
        return self._make_request('POST', 'meal-type/', json=data)