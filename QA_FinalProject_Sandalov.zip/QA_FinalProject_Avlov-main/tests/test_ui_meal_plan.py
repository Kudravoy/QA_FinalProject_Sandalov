import pytest
import allure
import time
from pages.meal_plan import MealPlanPage
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class TestMealPlan:

    """Проверяет корректность создания, просмотра, удаления плана питания и списка покупок"""

    @pytest.mark.ui
    @allure.title("Создать план питания")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_meal_plan(self, auth_driver, api_client, data_for_meal_plan, recipe_provider,
                              delete_meal_plans_after_test, cleanup_recipes):
        """
        Проверяет создание плана питания

        Шаги:
        1. Получает или создает рецепт через API при помощи фикстуры
        2. Открывает страницу просмотра планов питания
        3. Нажимает кнопку создания нового плана питания
        4. Выбирает дату для плана
        5. Заполняет форму создания плана
        6. Подтверждает создание плана
        7. Проверяет, что созданный план отображается на странице
        8. Удаляет план после теста при помощи фикстуры
        """

        meal_plan_page = MealPlanPage(auth_driver)

        data_for_meal_plan['recipe'] = recipe_provider('name') # Создает рецепт при его отсутствии

        # Регистрирует рецепт для его автоматического удаления
        cleanup_recipes(data_for_meal_plan['recipe'])

        # Открывает страницу просмотра планов питания и создает новый план
        meal_plan_page.open_view_meal_plan_page()
        time.sleep(3)
        meal_plan_page.create_meal_plan(data_for_meal_plan['day_number']) # Передается дата
        time.sleep(5)

        # Вводит необходимые данные и после проверяет, что план отображается на странице. По итогу прохождения план удаляется
        meal_plan_page.enter_title_meal_plan(**data_for_meal_plan)
        meal_plan_page.check_created_recipe(data_for_meal_plan['heading']) # Фикстурой передается наименование рецепта
        print("✅ Тест успешно завершен, план будет автоматически удален")

    @pytest.mark.ui
    @allure.title("Просмотреть созданный план питания")
    @allure.severity(allure.severity_level.NORMAL)
    def test_view_meal_plan(self, auth_driver, api_client, data_for_meal_plan_by_API_id,
                            recipe_provider, create_and_delete_meal_plan, data_for_meal_plan):
        """
        Проверяет просмотр созданного плана питания

        Шаги:
        1. Проверяет наличие рецепта при помощи фикстуры
        2. Создает план питания по средствам API при помощи фикстуры
        3. Получает название созданного рецепта из ответа API
        4. Открывает страницу просмотра планов питания
        5. Находит план по дате, названию рецепта
        6. Удаляет план после теста при помощи фикстуры
        """
        # Создает план питания через фикстуру (ВЫЗЫВАЕМ функцию, которую вернула фикстура)
        plan = create_and_delete_meal_plan(data_for_meal_plan_by_API_id)
        assert plan is not None, "План питания не создан"
        assert 'id' in plan, "Ответ не содержит ID"

        # Получает название рецепта
        if 'recipe' in plan and isinstance(plan['recipe'], dict):
            meal_plan_name = plan['recipe']['name']
        else:
            # Если API возвращает только ID рецепта, получает название через api_client
            recipe_id = data_for_meal_plan_by_API_id['recipe']
            recipe_info = api_client.get_recipe(recipe_id)
            meal_plan_name = recipe_info['name']

        meal_plan_heading = data_for_meal_plan['heading']
        print(f"✅ Создан план питания: {meal_plan_name}")

        # Открывает страницу просмотра планов питания и находит созданный план
        meal_plan_page = MealPlanPage(auth_driver)

        meal_plan_page.open_view_meal_plan_page()

        # Ищет план
        found = meal_plan_page.search_create_meal_plan(meal_plan_name, meal_plan_heading)
        assert found, f"План питания '{meal_plan_name}' не найден на странице"

        print("✅ Тест успешно завершен, план будет автоматически удален")

    @pytest.mark.ui
    @allure.title("Удалить план питания")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_delete_meal_plan(self, auth_driver, api_client, data_for_meal_plan, recipe_provider):
        """
        Проверяет удаление плана питания

        Шаги:
        1. Получает или создает рецепт через API при помощи фикстуры
        2. Открывает страницу просмотра планов питания
        3. Нажимает кнопку создания нового плана питания
        4. Выбирает дату для плана
        5. Заполняет форму создания плана
        6. Подтверждает создание плана
        9. Находит план по дате, названию рецепта
        10. Удаляет найденный план питания
        11. Проверяет успешность удаления плана питания через UI
        12. Проверяет успешность удаления плана питания через API

        """

        meal_plan_page = MealPlanPage(auth_driver)

        data_for_meal_plan['recipe'] = recipe_provider('name') # Создает рецепт при его отсутствии

        # # Открывает страницу просмотра планов питания и создает новый план
        meal_plan_page.open_view_meal_plan_page()# Создает план питания
        time.sleep(3)
        meal_plan_page.create_meal_plan(data_for_meal_plan['day_number'])
        time.sleep(3)
        meal_plan_page.enter_title_meal_plan(**data_for_meal_plan)
        time.sleep(2)
        auth_driver.refresh()
        time.sleep(3)
        meal_plan_page.open_view_meal_plan_page()

        # Выбирает ранее созданный план питания по дате и наименованию рецепта
        meal_plan_page.search_data_meal_plan(data_for_meal_plan["day_number"])  # Передается дата
        time.sleep(6)
        meal_plan_page.click_create_meal_plan(data_for_meal_plan["recipe"])
        meal_plan_page.click_create_meal_plan(data_for_meal_plan["recipe"]) # Повторно добавлено для надежности прохождения теста
        time.sleep(4)

        # Удаляет добавленный план
        meal_plan_page.delete_meal_plan()
        time.sleep(4)
        auth_driver.refresh()

        # Проверяет, что план удалён через UI
        try:
            meal_plan_page.search_create_meal_plan(data_for_meal_plan["recipe"], data_for_meal_plan["heading"])
            assert False, f"❌ План питания с рецептом '{data_for_meal_plan['recipe']}' не был удален!"
        except AssertionError as e:
            if "не был найден" in str(e):
                print(f"✓ План питания с рецептом '{data_for_meal_plan["recipe"]}' успешно удален (не найден на странице)")
            else:
                raise

        recipe_name = recipe_provider('name')  # Получает название рецепта, вызывая функцию

        # Проверяет, что план удалён через API
        updated_plans = api_client.get_meal_plan_list()

        plan_exists = False
        for plan in updated_plans.get('results', []):
            if plan.get('recipe_name') == recipe_name:  # Теперь сравниваем строки
                plan_exists = True
                break

        assert not plan_exists, f"❌ API проверка: План с рецептом '{recipe_name}' все еще существует!"
        print(f"✅ API проверка: План с рецептом '{recipe_name}' удален из системы")

    @pytest.mark.ui
    @allure.title("Добавить продукты в список покупок")
    @allure.severity(allure.severity_level.NORMAL)
    def test_check_shopping_list(self, auth_driver, api_client, data_for_meal_plan, recipe_provider,
                              delete_meal_plans_after_test):
        """
        Проверяет добавление продуктов в список покупок с последующим их удалением

        Шаги:
        1. Получает или создает рецепт через API при помощи фикстуры
        2. Открывает страницы просмотра планов питания
        3. Нажимает кнопку создания нового плана
        4. Выбирает даты для плана при помощи фикстуры
        5. Заполняет формы создания плана с отметкой "Добавить в список покупок":
        6. Подтверждает создания плана
        8. Переходит в раздел "Список покупок"
        9. Проверяет, что продукты из рецепта добавлены в список покупок
        10. Удаляет продукты из списка покупок при помощи фикстуры
        """
        meal_plan_page = MealPlanPage(auth_driver)

        # Создает рецепт при его отсутствии
        data_for_meal_plan['recipe'] = recipe_provider('name')

        # Открывает страницу просмотра планов питания и создает новый план с добавлением его в список покупок
        meal_plan_page.open_view_meal_plan_page()
        time.sleep(3)
        meal_plan_page.create_meal_plan(data_for_meal_plan['day_number'])
        time.sleep(5)
        meal_plan_page.enter_title_meal_plan_with_add_to_shopping_list(**data_for_meal_plan) #  Добавлен элемент "Лист покупок"
        auth_driver.refresh()
        time.sleep(4)

        # Проверяет список покупок с последующим удалением
        meal_plan_page.check_shopping_list() #Проверяет список покупок
        # meal_plan_page.open_view_meal_plan_page() #Открывает страницу просмотра планов питания
        print("✅ Тест успешно завершен, план будет автоматически удален")