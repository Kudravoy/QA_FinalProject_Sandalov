import pytest
import allure
import time
from pages.header_component import HeaderComponent
from pages.login_page import LoginPage


class TestHeaderComponent:

    """Проверяет корректность взаимодействия с элементами шапки сайта (header)"""

    @pytest.mark.ui
    @allure.title("Выйти из учетной записи")
    @allure.severity(allure.severity_level.NORMAL)
    def test_logout_account(self, driver):
        """
        Проверяет выход из учетной записи

        Шаги:
        1. Авторизирует пользователя
        2. Открывает главную страницу
        3. Открывает меню пользователя
        4. Выполняет выход и проверяет перенаправление на страницу авторизации
        """
        # Выполняет авторизацию пользователя
        login_page = LoginPage(driver) # Использует driver, так как тест разрушает сессию auth_driver, делая cookies невалидными
        login_page.login()
        time.sleep(3)  # Необходимо время

        meal_plan_page = HeaderComponent(driver)

        # Открывает меню, выходит и проверяет перенаправление на страницу авторизации
        meal_plan_page.click_account()
        time.sleep(3)
        meal_plan_page.click_logout()

    @pytest.mark.ui
    @allure.title("Ввести данные в строку поиска")
    @allure.severity(allure.severity_level.NORMAL)
    def test_search_recipe(self, auth_driver, recipe_provider):
        """Проверяет строку поиска рецепта

        Шаги:
        1. Открывает главную страницу
        2. Находит поле поиска и нажимает на него
        3. Вводит текст рецепта в поле поиска и проверяет его отображение на странице
        """
        # Получаем название рецепта (уже строка)
        recipe_name = recipe_provider('name')

        meal_plan_page = HeaderComponent(auth_driver)

        # Находит поле поиска и нажимает на него
        meal_plan_page.go_to_search()

        # Вводит наименование рецепта и проверяет, что он отображается
        meal_plan_page.enter_recipe_to_search(recipe_name)

        print(f"✅ Поиск рецепта '{recipe_name}' выполнен успешно")

    @pytest.mark.ui
    @allure.title("Импортировать рецепты по URL")
    @allure.severity(allure.severity_level.NORMAL)
    def test_import_recipe_list_url_header(self, auth_driver, api_client, cleanup_recipes):
        """
        Проверяет автоматическое импортирование списка рецептов URL из файла recipe_links.json

        Шаги:
        1. Открывает главную страницу
        2. Открывает страницу импорта рецептов
        3. Добавляет ссылки из файла recipe_links.json
        4. Импортирует рецепты и проверяет
        5. Автоматически удаляет импортированные рецепты (фикстура cleanup_recipes)
        """

        meal_plan_page = HeaderComponent(auth_driver)

        # Запоминает рецепты до импорта
        before_recipes = api_client.get_recipes()
        before_ids = {r['id'] for r in before_recipes.get('results', [])}

        # Импортирует рецепты
        meal_plan_page.go_to_import_recipe()
        time.sleep(2)
        meal_plan_page.import_recipe_list_url()
        time.sleep(2)
        meal_plan_page.start_import_recipe()

        # Получает рецепты после импорта
        after_recipes = api_client.get_recipes()
        after_ids = {r['id'] for r in after_recipes.get('results', [])}

        # Находит новые рецепты
        new_recipe_ids = after_ids - before_ids

        # Добавляет новые рецепты в фикстуру для автоматического удаления
        for recipe_id in new_recipe_ids:
            cleanup_recipes(recipe_id)  # ← добавляет ID в очередь на удаление

        print(f"📊 Импортировано новых рецептов: {len(new_recipe_ids)}")

        # Проверяет
        assert len(new_recipe_ids) > 0, "Не удалось импортировать рецепты"

        print("✅ Тест успешно завершен, рецепты будут автоматически удалены")

    @pytest.mark.ui
    @allure.title("Проверить создание рецепта")
    @allure.severity(allure.severity_level.NORMAL)
    def test_create_recipe_header(self, auth_driver, recipe_data_to_enter, cleanup_recipes, api_client):
        """
        Проверяет создание рецепта вручную

        Шаги:
        1. Открывает главную страницу
        2. Открывает страницу создания рецепта
        3. Заполняет необходимые поля создания рецепта
        4. Переходит на главную страницу
        5. Проверяет наличие созданного рецепта
        5. Автоматически удаляет созданный рецепт (фикстура cleanup_recipes)
        """

        meal_plan_page = HeaderComponent(auth_driver)
        time.sleep(3)
        # Открывает страницу создания рецепта
        meal_plan_page.go_to_create_recipe()

        # Заполняет форму создания рецепта
        meal_plan_page.enter_title_recipe(**recipe_data_to_enter)
        time.sleep(5)

        # Переходит на главную страницу и проверяет наличие созданного рецепта
        meal_plan_page.go_to_logo()
        recipe_name = recipe_data_to_enter["name"]  # Получаем имя рецепта из данных
        meal_plan_page.check_create_recipe(recipe_name)
        print(f"✅ Рецепт '{recipe_name}' был успешно создан")

        # Получает ID рецепта при помощи API и удаляет его (фикстура cleanup_recipes)
        response = api_client.get_recipes()
        if response and 'results' in response and response['results']:
            recipe_id = response['results'][0]['id']
            cleanup_recipes(recipe_id)

