import pytest
import allure

class TestAPIClient:
    """Тесты для проверки API клиента"""

    """Работоспособность API и выдача ошибок"""
    @pytest.mark.api
    @allure.title("Проверить соединение с API клиентом")
    @allure.severity(allure.severity_level.BLOCKER)
    def test_connection_to_api(self, api_client):
        """Проверка соединения с API"""
        print("\n=== Проверка соединения с API ===")

        # Пытаемся получить список рецептов
        response = api_client.get_recipes()

        # Проверяем, что сервер ответил
        assert response is not None, "Сервер не отвечает"
        assert 'results' in response, "Неверный формат ответа"

        print("✅ API доступен и работает корректно")

    @pytest.mark.api
    @allure.title("Проверить ошибку 404 (ресурс не найден)")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_api_error_404(self, api_client):
        """ Проверка ошибки 404 (ресурс не найден)"""

        print("\n=== Проверка ошибки 404 ===")

        # Пытаемся получить несуществующий рецепт
        fake_id = 999999999
        url = f"https://tandoor.vs1.srv.eduson.tv/api/recipe/{fake_id}/"

        response = api_client.session.get(url, headers=api_client.headers)

        print(f"Запрос к рецепту {fake_id} -> Статус: {response.status_code}")

        # Ожидаем 404 Not Found
        assert response.status_code == 404, \
            f"Ожидался 404, получен {response.status_code}"

        print("✅ Сервер правильно возвращает 404 для несуществующего ресурса")

    @pytest.mark.api
    @allure.title("Проверить ошибку 400 (неправильные данные)")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_api_error_400(self, api_client):
        """ Проверка ошибки 400 (неправильные данные)"""

        print("\n=== Проверка ошибки 400 ===")

        # Пытаемся создать рецепт без обязательных полей
        invalid_recipe = {"name": "Только имя"}  # Нет steps, servings

        response = api_client.session.post(
            "https://tandoor.vs1.srv.eduson.tv/api/recipe/",
            json=invalid_recipe,
            headers=api_client.headers
        )

        print(f"Создание рецепта без полей -> Статус: {response.status_code}")

        # Ожидаем 400 Bad Request
        assert response.status_code == 400, \
            f"Ожидался 400, получен {response.status_code}"

        print("✅ Сервер правильно возвращает 400 при невалидных данных")

    """Создание типов питания"""
    @pytest.mark.api
    @allure.title("Создать типа питания")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_meal_type(self, api_client, meal_types):
        """Тестирует создание нескольких типов питания через API"""
        created_ids = []

        for meal_type in meal_types:
            print(f"\n📝 Создаём тип питания: {meal_type['name']}")

            result = api_client.create_meal_type(meal_type)

            if result and 'id' in result:
                meal_type_id = result['id']
                print(f"✅ Тип питания создан с ID: {meal_type_id}")
                created_ids.append(meal_type_id)
            else:
                print(f"❌ Тип питания '{meal_type['name']}' не создан")
                assert False, f"Не удалось создать тип питания: {meal_type['name']}"

        # Проверяем, что создано 3 типа питания
        assert len(created_ids) == 3, f"Создано только {len(created_ids)} типов питания из 3"

    """Проверка работы API c рецептами"""
    @pytest.mark.api
    @allure.title("Получить список рецептов")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_get_recipes_returns_results_field(self, api_client):
        """Тестирует получение списка имеющихся рецептов через API"""
        response = api_client.get_recipes()
        assert 'results' in response
        assert isinstance(response['results'], list)
        print(f"✅ Найдено рецептов: {len(response['results'])}")

    @pytest.mark.api
    @allure.title("Создать рецепт")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_recipe(self, api_client, recipe_data):
        """Тестирует создание рецепта через API"""
        print(f"\n📝 Создаём рецепт: {recipe_data['name']}")

        result = api_client.create_recipe(recipe_data)

        if result and 'id' in result:
            recipe_id = result['id']
            print(f"✅ Рецепт создан с ID: {recipe_id}")
            assert recipe_id is not None
        else:
            print("❌ Рецепт не создан")
            assert False, "Не удалось создать рецепт"

    @pytest.mark.api
    @allure.title("Импортировать рецепты по URL")
    @allure.severity(allure.severity_level.NORMAL)
    def test_import_multiple_recipes_from_json(self, api_client, recipe_links, recipe_preparer):
        """Импортирует несколько рецептов по URL из JSON файла"""
        print(f"\n📚 Начинаем импорт {len(recipe_links)} рецептов...")

        results = {"success": [], "failed": []}

        for i, url in enumerate(recipe_links, 1):
            print(f"\n{'=' * 60}\n📌 Рецепт {i}/{len(recipe_links)}\n🔗 URL: {url}\n{'=' * 60}")

            # Импортирует рецепты из источников
            print(f"\n📥 Импортируем данные...")
            import_result = api_client.import_recipe_from_source(url)

            # Валидирует импортированные данные
            if not import_result or import_result.get('error'):
                error = import_result.get('msg', 'Unknown') if import_result else 'No response'
                print(f"❌ Ошибка: {error}")
                results["failed"].append({"url": url, "error": error})
                continue

            recipe_name = import_result.get('recipe', {}).get('name')
            if not recipe_name:
                print(f"❌ Нет названия рецепта")
                results["failed"].append({"url": url, "error": "No name"})
                continue

            print(f"✅ Распарсен: {recipe_name}")

            # Подготавливает данные для сохранения рецептов
            print(f"\n💾 Сохраняем...")
            save_data = recipe_preparer(import_result, url)  # Используем фикстуру
            print(f"📝 Шагов: {len(save_data['steps'])}")

            # Сохраняет рецепты
            save_result = api_client.create_recipe(save_data)

            if not save_result or 'id' not in save_result:
                print(f"❌ Не удалось сохранить")
                results["failed"].append({"url": url, "error": "Save failed", "name": recipe_name})
                continue

            recipe_id = save_result['id']
            print(f"✅ Сохранен с ID: {recipe_id}")

            # Подтверждает сохранение рецептов
            try:
                get_result = api_client._make_request('GET', f'recipe/{recipe_id}/')
                if get_result and get_result.get('name') == recipe_name:
                    print(f"✅ Подтвержден в базе!")
                    results["success"].append({"url": url, "name": recipe_name, "id": recipe_id})
                else:
                    print(f"⚠️ Создан, но не подтвержден")
                    results["success"].append({"url": url, "name": recipe_name, "id": recipe_id})
            except:
                print(f"⚠️ Создан, но не удалось проверить")
                results["success"].append({"url": url, "name": recipe_name, "id": recipe_id})

        # И
        print(f"\n{'=' * 60}")
        print(f"📊 ИТОГИ: ✅ {len(results['success'])} | ❌ {len(results['failed'])}")

        if results['success']:
            print(f"\n✅ Успешно импортированные рецепты:")
            for r in results['success']:
                print(f"  🆕 {r['name']} (ID: {r['id']})")

        if results['failed']:
            print(f"\n❌ Ошибки:")
            for r in results['failed']:
                print(f"  • {r.get('name', 'Unknown')}: {r['error']}")

        assert len(results['success']) > 0, "Не удалось импортировать ни одного рецепта"

    @pytest.mark.api
    @allure.title("Удалить все рецепты")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_delete_recipe(self, api_client):
        """Проверка удаления всех существующих рецептов"""

        response = api_client.get_recipes()
        recipes = response.get('results', [])

        if not recipes:
            pytest.skip("В системе нет рецептов для удаления")

        print(f"\n📊 Найдено рецептов: {len(recipes)}")

        deleted_count = 0

        for recipe in recipes:
            recipe_id = recipe['id']
            recipe_name = recipe.get('name', 'Без названия')

            print(f"\n🗑️ Удаляем: {recipe_name} (ID: {recipe_id})")

            # Удаляет рецепт
            delete_response = api_client.delete_recipe(recipe_id)

            if delete_response and delete_response.status_code == 204:
                print(f"  ✅ Рецепт {recipe_id} удалён")
                deleted_count += 1

                # Проверяет, что рецепта больше нет
                get_response = api_client.get_recipe_by_id(recipe_id)
                if get_response is None:
                    print(f"  ✅ Подтверждено: рецепт {recipe_id} не существует")
                else:
                    print(f"  ⚠️ Рецепт {recipe_id} всё ещё существует? Ответ: {get_response}")
            else:
                status = delete_response.status_code if delete_response else "None"
                print(f"  ❌ Не удалось удалить {recipe_id}. Статус: {status}")

        print(f"\n✅ Успешно удалено {deleted_count} из {len(recipes)} рецептов")

        # Финальная проверка удаления рецепта
        response_after = api_client.get_recipes()
        recipes_after = response_after.get('results', []) if response_after else []
        assert len(recipes_after) == 0, f"Осталось рецептов: {len(recipes_after)}"
        print("✅ Все рецепты удалены из системы")

    """Проверка работы API c планами питания"""

    @pytest.mark.api
    @allure.title("Создать план питания")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_create_meal_plan(self, api_client, recipe_provider, data_for_meal_plan_by_API_id):
        """Тестирует создание плана питания через API"""

        # Получаем ID рецепта (для логирования)
        recipe_id = recipe_provider('id')
        print(f"📝 Используем рецепт с ID: {recipe_id}")

        # Создаём план питания
        plan = api_client.create_meal_plan(data_for_meal_plan_by_API_id)

        # Проверяет, что план питания создался
        assert plan is not None, "План питания не создан"
        assert 'id' in plan, "Ответ не содержит ID"

        meal_plan_id = plan['id']
        print(f"✅ План питания создан с ID: {meal_plan_id}")

        # Проверяет, что план питания можно получить по ID
        fetched_plan = api_client.get_meal_plan_by_ID(meal_plan_id)

        # Проверка: Полученный план не пустой
        assert fetched_plan is not None, f"План с ID {meal_plan_id} не найден в базе"

        recipe_name = fetched_plan.get('recipe', {}).get('name', 'Без имени')
        print(f"✅ План подтверждён в базе: {recipe_name}")

        # Опционально: проверяем соответствие данных
        assert fetched_plan.get('id') == meal_plan_id, "ID плана не совпадает"

    @pytest.mark.api
    @allure.title("Получить количество планов питания")
    @allure.severity(allure.severity_level.NORMAL)
    def test_get_meal_plan_list(self, api_client):
        """Тестирует получение количества списков планов питания"""
        meal_plan_list = api_client.get_meal_plan_list()
        count = meal_plan_list.get('count', 0)
        print(f"Найдено планов питания: {count}")

    @pytest.mark.api
    @allure.title("Удалить все планы питания")
    @allure.severity(allure.severity_level.CRITICAL)
    def test_delete_meal_plan(self, api_client, data_for_meal_plan_by_API_id, meal_types):
        """Проверка удаления всех существующих планов питания"""

        #Создает план питания
        plan = api_client.create_meal_plan(data_for_meal_plan_by_API_id)
        print(f'Создан план питания: {plan['recipe']['name']}')

        #Получает количество действующих списков планов питания
        response = api_client.get_meal_plan_list()
        plans = response.get('results', [])

        if not plans:
            pytest.skip("Нет планов для удаления")

        print(f"Найдено планов: {len(plans)}")

        #Удаляет найденные планы питания
        for plan in plans:
            plan_id = plan['id']
            api_client.delete_meal_plan(plan_id)  # Не проверяем возврат
            print(f"✅ Удалён план {plan_id}")

        # Проверяет, что все удалены
        remaining = api_client.get_meal_plan_list()
        remaining_count = remaining.get('count', 0)
        assert remaining_count == 0, f"Осталось {remaining_count} планов"
        print("✅ Все планы удалены")

    """Проверка работы API со списком покупок"""

    @pytest.mark.api
    @allure.title("Добавить продукты в список покупок вручную")
    @allure.severity(allure.severity_level.NORMAL)
    def test_get_create_shopping_list(self, api_client, shopping_list_data):
        """Проверяет добавление продуктов в список покупок при помощи ввода данных (не по рецепту) с последующим удалением"""

        result = api_client.create_shopping_list(shopping_list_data)

        assert result is not None, "Элемент списка не создан"
        assert 'id' in result, "Ответ не содержит ID"

        shopping_list_by_ID = result['id']
        print(f"✅ Элемент списка создан с ID: {shopping_list_by_ID}")

        # Проверяет, что продукт можно получить по ID
        all_entries = api_client.get_shopping_list(shopping_list_by_ID)
        assert all_entries is not None, "Не удалось получить элементы списка"
        print()

        # Удаляет продукты после успешной проверки
        api_client.delete_shopping_list(shopping_list_by_ID)
        print(f"🗑️ Элемент списка {shopping_list_by_ID} удалён")

    @pytest.mark.api
    @allure.title("Добавить продукты в список покупок при помощи рецепта")
    @allure.severity(allure.severity_level.NORMAL)
    def test_get_create_shopping_list_on_recipe(self, api_client, shopping_list_data_on_recipe):
        """Проверяет добавление продуктов в список покупок при помощи существующего рецепта"""

        result = api_client.create_shopping_list_on_recipe(shopping_list_data_on_recipe)

        assert result is not None, "Элемент списка не создан"
        assert 'id' in result, "Ответ не содержит ID"

        shopping_list_by_recipe = result['id']
        print(f"✅ Элемент списка создан с ID: {shopping_list_by_recipe}")

        # Проверяет, что продукт можно получить по ID
        all_entries = api_client.get_shopping_list_on_recipe(shopping_list_by_recipe)
        assert all_entries is not None, "Не удалось получить элементы списка"

        # Удаляет продукты после успешной проверки
        api_client.delete_shopping_list_on_recipe(shopping_list_by_recipe)
        print(f"🗑️ Элемент списка {shopping_list_by_recipe} удалён")
        print(result)