import pytest
import allure
import time
import os
from pages.login_page import LoginPage
from selenium.webdriver.common.by import By

@pytest.mark.ui
@allure.title("Проверить авторизацию пользователя по средствам UI")
@allure.severity(allure.severity_level.CRITICAL)
def test_login_page(driver):
    """
    Проверяет успешную авторизацию пользователя.
    В последующих тестах авторизация пользователя происходит автоматически
    """

    login_page = LoginPage(driver)
    login_page.login()
    time.sleep(3)  # Необходимо время


    # Проверяет, что пользователь авторизован
    expected_url = os.getenv("BASE_URL").rstrip('/')
    current_url = driver.current_url.rstrip('/')

    assert current_url == expected_url, \
        f"Ошибка авторизации! Текущий URL: {driver.current_url}, ожидался: {expected_url}"

    print(f"Пользователь авторизован на сайте")