import time
import allure
from selenium.webdriver.common.by import By
from pages.base_page import BasePage
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import json
import os

# Класс элементов верхней панели навигации
class HeaderComponent(BasePage):

    # Локаторы компонентов header
    FIELD_LOGO = (By.XPATH, "//img[contains(@src, 'brand_logo')]/ancestor::a") # Логотип "Tandoor"
    FIELD_SEARCH = (By.CSS_SELECTOR, ".fa-search") # Кнопка "поиск"
    FIELD_SEARCH_TEXT = (By.CSS_SELECTOR, "input[placeholder='Search']")  # Поле ввода рецепта в поиске
    FIELD_PLUS = (By.CSS_SELECTOR, ".v-icon.fa-solid.fa-plus") # Кнопка "+" для всплывающего окна
    FIELD_CREATE_RECIPE = (By.XPATH, "//a[contains(@href, 'edit/recipe')]")  # Кнопка "Создать рецепт"
    FIELD_IMPORT_RECIPE = (By.CSS_SELECTOR, "a[href='/recipe/import']")  # Кнопка "Импортировать рецепт"
    FIELD_CLICK_ACCOUNT = (By.CSS_SELECTOR, ".v-avatar") # Кнопка учетной записи
    FIELD_LOGOUT = (By.CSS_SELECTOR, "a[href='/accounts/logout/']")  # Кнопка "Выйти"
    SETTINGS = (By.PARTIAL_LINK_TEXT, "/settings")  # Кнопка "Настройки" (в тестах не используется)
    HELP = (By.PARTIAL_LINK_TEXT, "/help")  # Кнопка "Помощь" (в тестах не используется)

    # Локаторы при переходе в импортирование рецепта
    #FIELD_NEXT = (By.XPATH,
                  #"//span[@class='v-btn__content' and text()='Следующий']/parent::button")  # Кнопка "Следующий"
    FIELD_NEXT = (By.CSS_SELECTOR, "button.text-success") # Кнопка "Следующий"
    FIELD_TEXT_AREA = (By.CSS_SELECTOR, ".v-field__input") #Поле ввода URL
    FIELD_IMPORT_BUTTON = (By.XPATH, "//span[@class='v-btn__content' and (text()='Импорт' or text()='Import')]/parent::button")#Кнопка "Импорт"
    FIELD_LIST_URL = (By.XPATH,
                      "//div[@class='v-card-title' and contains(text(), 'Список URL')] | //div[@class='v-card-title' and contains(text(), 'URL List')]")  # Переход в меню автоматического импорта списка URL адресов

    #Локаторы заполнения нового рецепта
    FIELD_NAME_RECIPE = (By.CSS_SELECTOR, "[aria-labelledby$='-label']") # Поле "Наименование"
    FIELD_DESCRIPTION = (By.TAG_NAME, "textarea") # Поле "Описание"
    FIELD_KEYWORD = (By.CSS_SELECTOR, "input[aria-placeholder='Ключевое слово'], input[aria-placeholder='Keyword']") # Поле "Ключевые слова"
    FIELD_WAITING_TIME = (By.CSS_SELECTOR, "input.v-field__input[inputmode='decimal'][type='text']") # Поле "Время ожидания"
    FIELD_WORKING_TIME = (By.CSS_SELECTOR, "[aria-labelledby='input-v-0-18-label']") # Поле "Время работы"
    FIELD_PORTION = (By.CSS_SELECTOR, "[aria-labelledby='input-v-0-23-label']") # Поле "Порции"
    FIELD_PORTION_DESCRIPTION = (By.CSS_SELECTOR, "[aria-labelledby='input-v-0-29-label']") # Поле "Описание порций"
    #FIELD_STEPS_TAB = (By.XPATH, "//i[contains(@class, 'fa-arrow-right')]/ancestor::button") # Элемент "Шаги"
    FIELD_STEPS_TAB = (By.CSS_SELECTOR, ".v-btn--variant-tonal")
    FIELD_INSTRUCTION_FIELD = (By.CSS_SELECTOR, ".auto-textarea-input") # Поле ввода инструкции
    FIELD_SAVE_RECIPE = (By.CSS_SELECTOR,
                         ".v-btn.v-btn--slim.v-theme--light.text-save.v-btn--density-default.v-btn--size-default.v-btn--variant-text") # Кнопка "Сохранить" рецепт

    def __init__(self, driver):
        super().__init__(driver)
        self.page_url = self.BASE_URL

    """Проверяет элементы header"""

    @allure.step("Нажать на логотип Tandoor")
    def go_to_logo(self):
        """Переход на главную страницу"""
        self.driver.find_element(*self.FIELD_LOGO).click() # Кликаем на логотип Tandor
        print("Перешли на главную страницу")

    @allure.step("Нажать на окно поискаа")
    def go_to_search(self):
        """Находит поле поиска и нажимает на него"""
        self.driver.find_element(*self.FIELD_SEARCH).click()
        time.sleep(3)

    @allure.step("Нажать на создание рецепта")
    def go_to_create_recipe(self):
        """ Переходит в создание рецепта"""
        element = WebDriverWait(self.driver, 10).until(
            EC.element_to_be_clickable(self.FIELD_PLUS)
        )
        element.click()
        self.driver.find_element(*self.FIELD_CREATE_RECIPE).click()
        print("Вы перешли в создание рецепта")


    @allure.step("Нажать на импортирование рецепта")
    def go_to_import_recipe(self):
        """Переход на страницу импорта рецептов"""
        try:
            # Закрывает возможные оверлеи
            try:
                overlay = WebDriverWait(self.driver, 3).until(
                    EC.element_to_be_clickable((By.XPATH, "//div[@class='v-overlay__scrim']"))
                )
                overlay.click()
                time.sleep(1)
            except:
                pass

            # Ждет пока элемент станет кликабельным
            import_btn = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable(self.FIELD_IMPORT_RECIPE)
            )
            # Прокручивает к элементу
            self.driver.execute_script("arguments[0].scrollIntoView(true);", import_btn)
            time.sleep(1)
            import_btn.click()
            print("✅ Перешли на страницу импорта рецептов")
        except Exception as e:
            print(f"❌ Ошибка при переходе к импорту: {e}")
            raise

    @allure.step("Нажать на пользователя для открытия списка дополнительных элементов")
    def click_account(self):
        """Нажимает на пользователя и открывает список дополнительных элементов (настройки, помощь, выйти)"""
        self.driver.find_element(*self.FIELD_CLICK_ACCOUNT).click()

    @allure.step("Нажать на выход из учетной записи")
    def click_logout(self):
        """Нажимает на кнопку выхода из учетной записи пользователя"""
        self.driver.find_element(*self.FIELD_LOGOUT).click()

        # Проверяет, что произошло перенаправление на страницу логина
        expected_url = "https://tandoor.vs1.srv.eduson.tv/accounts/login/?next=/"
        current_url = self.driver.current_url

        assert current_url == expected_url, \
            f"Ошибка! Ожидался URL: {expected_url}, Фактический URL: {current_url}"

        print(f"✅ Выход выполнен успешно. Текущий URL: {current_url}")

    """Проверяет поле поиска"""

    @allure.step("Ввести в поле поиска рецепт: {recipe}")
    def enter_recipe_to_search (self, recipe):
        """Вводит текст рецепта в поле поиска и проверяет его отображение на странице"""
        # Находит поле поиска и вводит наименование рецепт
        search_field = self.driver.find_element(*self.FIELD_SEARCH_TEXT)
        search_field.clear()
        search_field.send_keys(recipe)

        # Нажимает кнопку "Enter" для выполнения поиска
        search_field.send_keys(Keys.ENTER)
        print(f"🔍 Поиск: {recipe}")

        # Ждет и проверяет, что рецепт отображается на странице
        try:
            result = WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.XPATH, f"//p[@class='font-weight-bold mt-2' and contains(text(), '{recipe}')]"))
            )
            print(f"✅ Рецепт найден на странице: {recipe}")
            return result
        except:
            print(f"❌ Рецепт не найден: {recipe}")
            raise AssertionError(f"Рецепт '{recipe}' не отображается на странице")

    @allure.step("Посмотреть на главной странице рецепт: {name}")
    def check_create_recipe(self, name):
        """Проверяет отображение на главной странице созданного рецепта"""
        return self.driver.find_element(By.XPATH, f"//div[@class='ml-3']//p[contains(@class,'font-weight-bold') and contains(text(),'{name}')]")

    """Проверяет импорт рецептов"""

    @allure.step("Перейти в меню импорта рецептов по URL")
    def import_recipe_list_url(self):
        """Переходит в меню автоматического импорта списка URL адресов и добавляет их"""
        self.driver.find_element(*self.FIELD_LIST_URL).click()
        time.sleep(6)
        self.driver.find_element(*self.FIELD_NEXT).click()

        # Загружает ссылки из JSON файла
        json_path = os.path.join(os.path.dirname(__file__), "../test_data/recipe_links.json")
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        # Берет все ссылки из файла
        recipe_links = data.get("recipe_links", [])

        if not recipe_links:
            raise AssertionError("❌ В файле recipe_links.json нет ссылок")

        # Вводит все ссылки в текстовое поле (каждая с новой строки)
        textarea = self.driver.find_element(*self.FIELD_TEXT_AREA)
        textarea.clear()

        for i, url in enumerate(recipe_links):
            textarea.send_keys(url)
            if i < len(recipe_links) - 1:  # Добавляем перенос строки, кроме последней ссылки
                textarea.send_keys("\n")

        print(f"✅ Введено {len(recipe_links)} ссылок для импорта")
        time.sleep(2)

    @allure.step("Импортировать рецепты по URL")
    def start_import_recipe(self):
        """Начинает процесс импорта с последующей проверкой на предмет их добавления"""
        self.driver.find_element(*self.FIELD_IMPORT_BUTTON).click()
        print("✅ Нажата кнопка 'Импорт'")
        time.sleep(60) #Ввиду большого объема информации, требуется длительное время на загрузки

        # Проверяем завершение импорта
        try:
            WebDriverWait(self.driver, 40).until(
                EC.presence_of_element_located(
                    (By.XPATH, "//span[@class='v-btn__content' and (text()='Сбросить' or text()='RESET' or text()='Reset')]/parent::button"))
            )
            print("Импорт успешно завершен")
            return True
        except TimeoutException:
            # Делаем скриншот и выбрасываем исключение
            self.driver.save_screenshot("import_timeout.png")
            raise AssertionError("❌ Импорт не завершился за 30 секунд")

    """Проверяет создание рецепта"""

    @allure.step("Заполнить данные создания рецепта {name}")
    def enter_title_recipe(self, name: object, description: object, key_word: object, waiting_time: object,
                           working_time: object, portion: object, portion_description: object,
                           instruction: object) -> None:
        """Заполняет форму создания рецепта"""
        name_recipe = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_NAME_RECIPE))
        name_recipe.send_keys(name) # Заполняет поле "Наименование"

        field_description = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_DESCRIPTION))
        field_description.send_keys(description) # Заполняет поле "Описание"

        field_keyword = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_KEYWORD))
        field_keyword.send_keys(key_word) # Заполняет поле "Ключевые слова"

        field_waiting_time = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_WAITING_TIME))
        field_waiting_time.send_keys(waiting_time) # Заполняет поле "Время ожидания"

        field_working_time = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_WORKING_TIME))
        field_working_time.send_keys(working_time) # Заполняет поле "Время работы"

        field_portion = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_PORTION))
        field_portion.send_keys(portion) # Заполняет поле "Порции"

        field_portion_description = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_PORTION_DESCRIPTION))
        field_portion_description.send_keys(portion_description) # Заполняет поле "Описание порций"

        field_steps_tab = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_STEPS_TAB))
        field_steps_tab.click() # Нажимает кнопку "Шаги" и переходит в окно с шагами

        field_instruction_field = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_INSTRUCTION_FIELD))
        field_instruction_field.send_keys(instruction)  # Заполняет поле "Ключевые слова"

        field_save_recipe = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_SAVE_RECIPE))
        field_save_recipe.click()
