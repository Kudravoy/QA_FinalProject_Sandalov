from pages.base_page import BasePage
import time
import allure
from selenium.common import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver import Keys
from selenium.webdriver.remote.webelement import WebElement

class MealPlanPage(BasePage):
    """Страница создания плана питания"""

    """Локаторы элементов"""
    FIELD_RECEPT = (By.CSS_SELECTOR, "input[aria-placeholder='Рецепт'], input[aria-placeholder*='Recipe']") # Поле рецепт
    FIELD_HEADING = (By.CSS_SELECTOR, "input[type='text'].v-field__input") # Поле "Заголовок"
    FIELD_DATE = (By.CSS_SELECTOR, "input[type='text'][placeholder='dd.mm.yyyy']") # Поле "Дата"
    FIELD_TIME = (By.CSS_SELECTOR, "input[value='12:00']") # Поле "Время"
    FIELD_HOUR = (By.CSS_SELECTOR, "input[value='12']") # Поле "Час"
    FIELD_MINUTE = (By.CSS_SELECTOR, "input[value='00']") # Поле "Минута"
    FIELD_TYPE_FOOD = (By.CSS_SELECTOR, "input[aria-placeholder='Тип питания'], input[aria-placeholder*='Meal type'] ") # Поле "Тип питания"
    FIELD_PORTION = (By.CSS_SELECTOR, "input[inputmode='decimal']") # Поле "Порции"
    FIELD_NOTE = (By.TAG_NAME, "textarea") # Поле "Заметка"
    FIELD_CREATE = (By.CSS_SELECTOR, ".v-btn.text-save") # Кнопка "Создать"
    FIELD_ADD_TO_SHOPPING_LIST = (By.CSS_SELECTOR,
                                  "input[aria-label='Добавить в лист покупок'], input[aria-label*='Add to shopping list']") # Кнопка "Добавить в список покупок"
    FIELD_SHOPPING = (By.LINK_TEXT, "Shopping") # Кнопка "Shopping"
    FIELD_SHOPPING_LIST = (By.XPATH,
                           '//span[contains(text(), "Лист покупок") or contains(text(), "Shopping List")]') # Кнопка "Лист покупок"


    def __init__(self, driver):
        """ Конструктор страницы планов питания."""
        super().__init__(driver)
        self.page_url = f"{self.BASE_URL}"

    """Создание планов питания"""

    @allure.step("Открыть главную страницу")
    def open_create_meal_plan_page(self):
        """Открывает главную страницу создания планов питания"""
        self.driver.get(self.page_url)

    @allure.step("Создать план питания для даты: {day_number}")
    def create_meal_plan(self, day_number):
        """Открывает окно для создания плана питания"""

        # Примечание: множественный клик используется из-за перекрытия элемента другим слоем.
        # При первом клике DOM обновляется, последующие клики попадают уже по нужному элементу.


        xpath = f"//div[contains(@class, 'cv-day') and contains(@class, 'd{day_number}')]" #Номер дня для создания плана

        # Первый клик - находим элемент заново
        element = self.driver.find_element(By.XPATH, xpath)
        self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
        time.sleep(2)
        self.driver.execute_script("arguments[0].click();", element)
        time.sleep(2)

        # Второй клик - снова находим элемент (он мог обновиться)
        element = self.driver.find_element(By.XPATH, xpath)
        self.driver.execute_script("arguments[0].click();", element)
        time.sleep(3)
        print("✅ Окно для создания плана питания открыто")

    @allure.step("Заполнить данные для создания плана питания (без добавления в список покупок)")
    def enter_title_meal_plan(self, recipe: object, heading: object, hour: object, minute: object, type_food: object, number_servings: object, note: object, day_number=None) -> None:
        """Заполняет форму создания плана питания"""
        field_recept = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_RECEPT))
        field_recept.send_keys(recipe) # Заполняет поле "Рецепт"
        time.sleep(2)
        field_recept.send_keys(Keys.ENTER) # Подтверждает ввод поля "Рецепт"
        self.driver.find_element(*self.FIELD_HEADING).send_keys(heading) #Заполняет поле "Заголовок"
        field_time= WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_TIME))
        field_time.click()  # Заполняет поле "Рецепт"
        self.driver.find_element(*self.FIELD_HOUR).send_keys(hour) #Заполняет поле "Час"
        minute_field = self.driver.find_element(*self.FIELD_MINUTE) #Заполняет поле "Минута"
        minute_field.send_keys(str(minute))
        minute_field.send_keys(Keys.ENTER) #Нажимает кнопку "Минута"
        self.driver.find_element(*self.FIELD_TYPE_FOOD).send_keys(type_food) #Заполняет поле "Тип питания"
        self.driver.find_element(*self.FIELD_TYPE_FOOD).send_keys(Keys.ENTER) #Подтверждает ввод поля "Тип питания"
        time.sleep(2)
        field_portion = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_PORTION))
        field_portion.clear() #Предварительно очищает поле "Порции"
        field_portion.send_keys(number_servings) #Заполняет поле "Порции"
        self.driver.find_element(*self.FIELD_NOTE).send_keys(note) #Заполняет поле "Заметка"
        self.driver.find_element(*self.FIELD_NOTE).send_keys(Keys.ESCAPE)
        time.sleep(0.5)
        field_create = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_CREATE))
        field_create.click()  #Нажимает кнопку "Создать"

    @allure.step("Заполнить данные для создания плана питания (с добавлением в список покупок)")
    def enter_title_meal_plan_with_add_to_shopping_list(self, recipe: object, heading: object, hour: object, minute: object, type_food: object, number_servings: object, note: object, day_number=None) -> None:
        """Заполняет форму создания плана питания и добавляет план в список покупок"""
        field_recept = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_RECEPT))
        field_recept.send_keys(recipe)
        time.sleep(2)
        field_recept.send_keys(Keys.ENTER)
        self.driver.find_element(*self.FIELD_HEADING).send_keys(heading)
        field_time = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_TIME))
        field_time.click()
        self.driver.find_element(*self.FIELD_HOUR).send_keys(hour)
        minute_field = self.driver.find_element(*self.FIELD_MINUTE)
        minute_field.send_keys(str(minute))
        minute_field.send_keys(Keys.ENTER)
        self.driver.find_element(*self.FIELD_TYPE_FOOD).send_keys(type_food)
        self.driver.find_element(*self.FIELD_TYPE_FOOD).send_keys(Keys.ENTER)
        time.sleep(2)
        field_portion = WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable(self.FIELD_PORTION))
        field_portion.clear()
        field_portion.send_keys(number_servings)
        self.driver.find_element(*self.FIELD_NOTE).send_keys(note)
        self.driver.find_element(*self.FIELD_ADD_TO_SHOPPING_LIST).click() #Нажимает кнопку "Добавить в список покупок"
        self.driver.find_element(*self.FIELD_CREATE).click()

    """Просмотр планов питания"""

    @allure.step("Открыть страницу планов питания")
    def open_view_meal_plan_page(self):
        """Открывает страницу просмотра планов питания"""
        self.driver.get(f"{self.page_url}/mealplan")

    @allure.step("Найти на странице план питания")
    def search_create_meal_plan(self, recipe, heading):
        """Находит на странице план питания"""

        # Прокручиваем страницу вниз для загрузки всех элементов
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)

        try:
            # Поиск по названию рецепта с ожиданием
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.XPATH, f"//*[contains(text(), '{recipe}')]"))
            )
            print(f"✓ Найден план по рецепту: {recipe}")
            return True
        except:
            try:
                # Поиск по заголовку
                WebDriverWait(self.driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, f"//*[contains(text(), '{heading}')]"))
                )
                print(f"✓ Найден план по заголовку: {heading}")
                return True
            except:
                print(f"✗ План не найден ни по рецепту '{recipe}', ни по заголовку '{heading}'")
                raise AssertionError(f"План питания с рецептом '{recipe}' не был найден")

    """Удаление планов питания"""

    @allure.step("Удалить текущий план питания")
    def delete_meal_plan(self):
        """Удаляет текущий выбранный план питания"""
        try:
            # Ожидание появления первой кнопки удаления
            delete_btn = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, '//button[contains(@class, "text-delete")]'))
            )
            delete_btn.click()
            print("✓ Первая кнопка 'Удалить' нажата")
            time.sleep(3)

            # Ожидание появления второй кнопки подтверждения
            confirm_btn = WebDriverWait(self.driver, 5).until(
                EC.element_to_be_clickable((By.XPATH,
                                            "//span[@class='v-btn__content' and (text()='Удалить' or text()='Delete')]/parent::button"))
            )
            confirm_btn.click()
            print("✓ Удаление подтверждено")

        except Exception as e:
            print(f"Ошибка при удалении: {e}")
            raise

    """Поиск по дате плана питания"""

    @allure.step("Выбрать дату с числом: {date_meal_plan}")
    def search_data_meal_plan(self, date_meal_plan):
        """Выбирает дату созданного плана питания"""
        element = self.driver.find_element(By.CSS_SELECTOR,
                                           'input[placeholder="dd.mm.yyyy"], input[placeholder="mm/dd/yyyy"]') # Дата в формате "dd.mm.yyyy"
        time.sleep(2)
        element.clear()  # # Очищает поле от старого значения
        time.sleep(2)
        element.send_keys(date_meal_plan)
        time.sleep(2)
        element.send_keys(Keys.ENTER) # Подтверждение ввода

    """Выбор плана питания"""

    @allure.step("Найти план питания по рецепту: {recipe}")
    def click_create_meal_plan(self, recipe):
        """Находит на странице плана питания рецепт и кликает по нему (множественный клик)"""

        # Более простой XPath без проверки на точный класс
        xpath = f"//span[contains(text(), '{recipe}')]"

        # Увеличиваем ожидание до 20 секунд
        for i in range(3):
            try:
                # Ждем появления элемента
                element = WebDriverWait(self.driver, 20).until(
                    EC.presence_of_element_located((By.XPATH, xpath))
                )

                # Скроллим к элементу
                self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", element)
                time.sleep(0.5)

                # Кликаем через JavaScript
                self.driver.execute_script("arguments[0].click();", element)
                time.sleep(1)
            except Exception as e:
                time.sleep(2)

        print("✅ План питания найден и выбран")

    """Проверка списка покупок"""

    @allure.step("Проверить список покупок")
    def check_shopping_list(self):
        """Проверяет содержимое списка покупок"""

        wait = WebDriverWait(self.driver, 10)

        # Переходит на страницу /shopping
        self.driver.get(f"{self.page_url}/shopping")
        print(f"🔍 Переход на страницу: {self.page_url}/shopping")

        # Ждет перехода на страницу /shopping
        wait.until(EC.url_contains("/shopping"))
        time.sleep(2)  # Дополнительная задержка для загрузки содержимого
        print("✅ Страница /shopping загружена")

        # Получает количество позиций
        try:
            shopping_element = wait.until(EC.presence_of_element_located(self.FIELD_SHOPPING_LIST))
            text = shopping_element.text
            print(f"📝 Текст элемента: '{text}'")

            # Извлекает число из текста
            numbers = ''.join(filter(str.isdigit, text))

            if numbers:
                number_shopping_list = int(numbers)

                # Проверяет
                if number_shopping_list > 0:
                    print(f"✅ Лист покупок добавлен. Найдено {number_shopping_list} позиций")
                    return True
                else:
                    print(f"❌ Список покупок пуст (число = {number_shopping_list})")
                    return False
            else:
                print(f"⚠️ Не удалось извлечь число из текста: '{text}'")
                # Пробует найти элементы ингредиентов
                ingredients = self.driver.find_elements(By.XPATH,
                                                        "//*[contains(@class, 'ingredient') or contains(@class, 'item')]")
                if len(ingredients) > 0:
                    print(f"✅ Найдено {len(ingredients)} ингредиентов")
                    return True
                else:
                    print("❌ Ингредиенты не найдены")
                    return False

        except Exception as e:
            print(f"❌ Ошибка при проверке списка покупок: {e}")

            # Выводит текст страницы для диагностики
            body_text = self.driver.find_element(By.TAG_NAME, "body").text
            print(f"Текст страницы:\n{body_text[:500]}")
            return False

    @allure.step("Проверить отображение плана питания")
    def check_created_recipe(self, meal_name):
        """Проверяет, что созданный план питания отображается на странице"""

        wait = WebDriverWait(self.driver, 10)

        try:
            # Ищет созданный план питания по названию
            created_meal = wait.until(
                EC.presence_of_element_located(
                    (By.XPATH, f"//*[contains(text(), '{meal_name}')]")
                )
            )
            print(f"✅ План питания '{meal_name}' успешно создан и отображается на странице")
            return created_meal
        except:
            raise Exception(f"План питания '{meal_name}' не найден на странице")

