import os
import json
import allure

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pages.base_page import BasePage
from dotenv import load_dotenv
import time

load_dotenv()

class LoginPage(BasePage):
    """ Page Object для страницы авторизации"""
    """Локаторы элементов"""
    USERNAME_INPUT = (By.ID, "id_login")  # Поле ввода имени пользователя
    PASSWORD_INPUT = (By.ID, "id_password")  # Поле ввода пароля
    SUBMIT_BUTTON = (By.CSS_SELECTOR, "button[type='submit']")    # Кнопка отправки формы (Войти)
    ERROR_MESSAGE = (By.CLASS_NAME, "alert alert-block alert-danger")   # Сообщение об ошибке (отображается при неверных данных)
    USER_AUTHORIZATION = (By.XPATH, "//div[@class='v-list-item-title' and text()='Выйти']") # Элемент, который появляется только у авторизованного пользователя

    def __init__(self, driver):
        """Конструктор страницы авторизации"""
        super().__init__(driver)
        self.page_url = f"{self.BASE_URL}/accounts/login/?next=/" # Формируем полный URL страницы логина

    """Страница авторизации"""

    @allure.step("Открыть страницу авторизации")
    def open_authorization_page(self) -> 'LoginPage':
        """Открывает страницу авторизации"""
        self.open_page_tandoor(self.page_url)
        return self

    @allure.step("Авторизоваться в системе")
    def login(self):
        """Выполняет вход в систему"""
        self.open_authorization_page()
        username = os.getenv("TANDOOR_USERNAME")
        password = os.getenv("TANDOOR_PASSWORD")
        self.input_text(self.USERNAME_INPUT, username)
        self.input_text(self.PASSWORD_INPUT, password)
        self.click(self.SUBMIT_BUTTON)

        time.sleep(5)

        if self.is_login_successful():
            cookies = self.driver.get_cookies()
            with open('cookies.json', 'w', encoding='utf-8') as f:
                json.dump(cookies, f)

        return self

    @allure.step("Проверить успешность авторизации")
    def is_login_successful(self) -> bool:
        """Проверяет успешность авторизации"""
        return "tandoor.vs1.srv.eduson.tv" in self.driver.current_url
