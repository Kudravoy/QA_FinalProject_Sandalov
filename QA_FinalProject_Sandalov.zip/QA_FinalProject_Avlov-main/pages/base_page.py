import os
import allure
from typing import Tuple
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementClickInterceptedException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.remote.webdriver import WebDriver

class BasePage(object):
    """
    Базовый класс для работы с общими элементами веб-страницы, содержащий методы:
    - поиск элементов
    - клики
    - ввод текста
    - получение текста
    - работа с ожиданиями
    """

    def __init__(self, driver: WebDriver, timeout: int=10):
        """Инициализация базовой страницы"""
        self.BASE_URL = os.getenv("BASE_URL")
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)
        self.timeout = timeout

    @allure.step("Открыть главную страницу сайта")
    def open_page_tandoor (self, url: str = ""):
        """Открывает начальную страницы сайта"""
        self.driver.get(self.BASE_URL)
        return self

    @allure.step("Найти на странице элемент")
    def find_element(self, locator, timeout=10):
        """Находит элементы на странице"""
        return WebDriverWait(self.driver, timeout).until(
            EC.presence_of_element_located(locator)
        )

    @allure.step("Кликнуть на элемент")
    def click(self, locator: Tuple[str, str]) -> None:
        """Кликает по элементу"""
        element = None
        try:
            element = self.wait.until(EC.element_to_be_clickable(locator))  # Ждет, пока элемент станет кликабельным
            element.click()
        except (ElementClickInterceptedException, Exception) as e: # Использует JavaScript, если элемент перекрыт
            print(f"Обычный клик не сработал: {e}, пробуем JS")
            if element:
                self.driver.execute_script("arguments[0].click();", element)
            else:
                raise

    @allure.step("Ввести текст в поле ввода")
    def input_text(self, locator: Tuple[str, str], text: str) -> None:
        """Вводит текст в поле ввода"""
        try:
            element = self.wait.until(EC.presence_of_element_located(locator))
            element.clear()
            element.send_keys(text)
        except Exception as e:
            print(f"Ошибка при вводе текста в {locator}: {e}")
            raise Exception(f"Не удалось ввести текст: {e}")

    @allure.step("Получить текстовое содержимое элемента")
    def get_text(self, locator: Tuple[str, str]) -> str:
        """Получает текст из элемента"""
        try:
            element = self.find_element(locator)
            return element.text
        except Exception as e:
            print(f"Ошибка при получении текста из {locator}: {e}")
            return ""